# H1B-Data-Analysis
This project aims to perform analysis on H1B applications of immigrants using different database approaches such as SQL Server, Azure Cosmos DB, Azure Data Factory &amp; Snowflake 

------------------------------- NOTE ----------------------------------

The dataset present here is compact dataset due to space restriction of Git. The link to original data set for tabels and data cleaning can be found here in the drive (https://drive.google.com/drive/folders/1PHKnbMj798z1pHfkw0ucZ7RDSPQEhe9d?usp=sharing) 
